#!/usr/bin/env sh
./../../tools/oxyresbuild -x xmls/res.xml --src_data data --dest_data data --compress pvrtc
