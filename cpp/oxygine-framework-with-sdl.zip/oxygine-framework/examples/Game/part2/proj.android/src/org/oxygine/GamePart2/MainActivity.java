package org.oxygine.GamePart2;

import org.oxygine.lib.OxygineActivity;

public class MainActivity extends OxygineActivity
{

}
