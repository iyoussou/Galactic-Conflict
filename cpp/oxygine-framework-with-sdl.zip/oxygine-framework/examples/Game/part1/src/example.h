void example_preinit();
void example_init();
void example_destroy();
void example_update();
