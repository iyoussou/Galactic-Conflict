package org.oxygine.HelloFlow;

import org.oxygine.lib.OxygineActivity;

public class MainActivity extends OxygineActivity
{

}
